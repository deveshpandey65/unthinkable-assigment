const Product = require("../models/Product");
const nlp = require("compromise");

// Keywords per language
const keywordsMap = {
    en: {
        add: ["add", "buy", "need", "want", "get", "pick up", "grab", "purchase"],
        remove: ["remove", "delete", "take out", "get rid of", "erase", "cross off", "take off"],
        show: ["show list", "show", "what's in my list", "see", "view", "read"],
        suggest: ["suggest", "recommend", "give me ideas for", "advice", "tips"],
        complete: ["complete", "done", "finished", "got", "checked off"],
        order: ["order", "checkout", "buy now", "place order"],

        seasonal: ["seasonal", "season", "in season", "current season", "monthly specials"],
        similar: ["similar", "alternative", "substitute", "replace", "other options", "other choices"],
        recommended: ["recommend", "recommended", "recommendation", "best picks", "top picks"]
    }
};

// Quantity extractor
function parseQuantity(text) {
    const doc = nlp(text);
    let numbers = doc.numbers().values().toNumber().out("array");
    if (numbers.length > 0) return numbers[0];

    if (/\b(a|an|half|dozen)\b/i.test(text)) {
        const map = { a: 1, an: 1, half: 0.5, dozen: 12 };
        const match = text.match(/\b(a|an|half|dozen)\b/i)[0].toLowerCase();
        return map[match] || 1;
    }

    return 1;
}

// Try matching product from DB
async function findProductInText(text) {
    const cleanText = text.toLowerCase().replace(/[^\w\s]/g, "");
    const products = await Product.find({}, "name brand").lean();
    for (const p of products) {
        if (cleanText.includes(p.name.toLowerCase())) {
            return p;
        }
    }
    return null;
}

// Main parser
async function parseVoiceCommand(text, lang = "en") {
    const lowerText = text.toLowerCase();
    const langKeywords = keywordsMap[lang] || keywordsMap.en;
    const doc = nlp(lowerText);

    // --- SHOW LIST ---
    if (langKeywords.show.some(kw => lowerText.includes(kw))) {
        return { intent: "show" };
    }

    // --- ADD ITEM ---
    if (langKeywords.add.some(kw => lowerText.includes(kw))) {
        const quantity = parseQuantity(text);
        const product = await findProductInText(text);
        return { intent: "add", product, quantity };
    }

    // --- REMOVE ITEM ---
    if (langKeywords.remove.some(kw => lowerText.includes(kw))) {
        const quantity = parseQuantity(text);
        const product = await findProductInText(text);
        return { intent: "remove", product, quantity };
    }

    // --- SUGGEST / SEASONAL / SIMILAR ---
    if (langKeywords.suggest.some(kw => lowerText.includes(kw))) {
        return { intent: "suggest" };
    }
    if (langKeywords.seasonal.some(kw => lowerText.includes(kw))) {
        return { intent: "seasonal" };
    }
    if (langKeywords.similar.some(kw => lowerText.includes(kw))) {
        const product = await findProductInText(text);
        return { intent: "similar", product };
    }

    // --- COMPLETE ---
    if (langKeywords.complete.some(kw => lowerText.includes(kw))) {
        return { intent: "complete" };
    }

    // --- ORDER ---
    if (langKeywords.order.some(kw => lowerText.includes(kw))) {
        // Check if user wants to order the whole cart
        if (lowerText.includes("cart")) {
            return { intent: "order", type: "cart" };
        }

        // Else try to find a product name to order
        const product = await findProductInText(text);
        return { intent: "order", type: "product", product };
    }

    // --- UNKNOWN ---
    return { intent: "unknown" };
}

module.exports = { parseVoiceCommand };
